package com.investmobile.invest;

/**
 * Created by thad on 11/10/15.
 */
public enum FavoriteTypeEnum {
    STOCK, MUTUAL_FUND, INDEX
}
