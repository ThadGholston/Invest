package com.investmobile.invest;

/**
 * Created by thad on 11/9/15.
 */
public class News {
    public String title;
    public String description;
    public String publicationDate;
    public String link;
}
