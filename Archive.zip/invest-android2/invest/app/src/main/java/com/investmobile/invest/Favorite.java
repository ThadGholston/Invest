package com.investmobile.invest;

/**
 * Created by thad on 11/10/15.
 */
public class Favorite {
    public FavoriteTypeEnum type;
    public String symbol;
    public String name;

}
