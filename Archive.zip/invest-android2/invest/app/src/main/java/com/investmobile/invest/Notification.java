package com.investmobile.invest;

/**
 * Created by thad on 11/15/15.
 */
public class Notification {
    public int id;
    public String symbol;
    public double price;
    public boolean lessThan;
    public boolean equalTo;
    public boolean greaterThan;
}
