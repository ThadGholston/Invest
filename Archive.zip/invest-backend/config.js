exports.db = {
	host: 'frankencluster.com',
	user: 'g02dbf15admin',
	password: 'tw1pvTQq2E(A',
	database: 'g02dbf15'
};

exports.salt = 'prub?Af-5ESTu#=t!udruD7EnE5EpHAs7uZaWRUDr&vacHA25*?JezucREyena$A';

exports.secret = 'thAyE4EtaQ*7AcU@ek5t+a#h#TET7*@hpAs#8f!8u-res3Wa2aGA=afuqa!est4t';